/*
 * File:   sub.c
 * Author: User
 *
 * Created on 2017?11?2?, ?? 4:51
 */


#include <xc.h>

int sub( int a , int b )
{
    return a - b;
}

