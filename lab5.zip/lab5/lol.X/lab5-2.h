/* 
 * File:   lab5-2.h
 * Author: User
 *
 * Created on 2017?11?2?, ?? 4:55
 */

int add( int a , int b );
int sub( int a , int b );

