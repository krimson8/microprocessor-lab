/*
 * File:   newmain.c
 * Author: User
 *
 * Created on 2017?11?2?, ?? 4:54
 */


#include <xc.h>
#include "lab5-2.h"
void main(void) {
    int adder = add(2,1);
    int suber = sub(2,1);
    return;
}
